
#Para instalar los paquetes, vamos a correr este código


install.packages("tidyverse", dependencies=TRUE)
install.packages("devtools")
install.packages("sf")
install.packages("eph")
install.packages("rpart")
install.packages("pdp")
install.packages("shiny")
install.packages("openxlsx")
install.packages("ggridges")
install.packages("ggthemes")
install.packages("foreign")
install.packages("janitor")
install.packages("plotly")
